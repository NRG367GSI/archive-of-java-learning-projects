public class Main {
    public static void main(String[] args) {
        Integer num = 5;
        String street = "Манежная ";
        if (num.equals(5)) {
            System.out.println(true);
        }
        if (((Integer) street.length()).equals(num)) { //length() возвращает int
            System.out.println(true);
        } else {
            System.out.println(false);
        }
        int numInt = num.intValue();
        numInt = (int) num;

        street.


    }

}